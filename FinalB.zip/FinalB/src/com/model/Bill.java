package com.model;
import java.io.Serializable;
import java.lang.String;

public class Bill implements Serializable{
	
	private String billid,billdt,std,lsame,lother,ll,sms,isd,amount;
	private Customer customer;
	public Bill(String billid, String billdt, String std, String lsame,
			String lother, String ll, String sms, String isd, String amount,
			Customer customer) {
		super();
		this.billid = billid;
		this.billdt = billdt;
		this.std = std;
		this.lsame = lsame;
		this.lother = lother;
		this.ll = ll;
		this.sms = sms;
		this.isd = isd;
		this.amount = amount;
		this.customer = customer;
	}
	public String getBillid() {
		return billid;
	}
	public String getBilldt() {
		return billdt;
	}
	public String getLsame() {
		return lsame;
	}
	public String getLother() {
		return lother;
	}
	public String getLl() {
		return ll;
	}
	public String getSms() {
		return sms;
	}
	public String getIsd() {
		return isd;
	}
	public String getAmount() {
		return amount;
	}
	public Customer getCustomer() {
		return customer;
	}
	public String getStd() {
		return std;
	}

	
}
