package com.model;

import java.io.Serializable;

public class Customer implements Serializable
{
	private String id,name,address,e_mail_id,phn_no;

	
	public Customer(String id, String name, String address, String e_mail_id, String phn_no) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
		this.e_mail_id = e_mail_id;
		this.phn_no= phn_no;
		
		
	}


	public String getId() {
		return id;
	}


	


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getE_mail_id() {
		return e_mail_id;
	}


	public void setE_mail_id(String e_mail_id) {
		this.e_mail_id = e_mail_id;
	}


	public String getPhn_no() {
		return phn_no;
	}


	public void setPhn_no(String phn_no) {
		this.phn_no = phn_no;
	}
	
	
	

}
