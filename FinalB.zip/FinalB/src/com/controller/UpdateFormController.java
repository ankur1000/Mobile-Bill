package com.controller;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import pack.CustFileIO;

import com.model.Customer;
import com.view.AddCustForm;
import com.view.CustViewAll;
import com.view.UpdateForm;


public class UpdateFormController implements KeyListener{
	private UpdateForm up;
	private ArrayList<Customer> cusList;
	public UpdateFormController(UpdateForm up1) {
		this.up=up1;
		try {
				cusList=CustFileIO.readObj();
			} 
			catch (FileNotFoundException e) {
			
				e.printStackTrace();
			} 
			catch (IOException e) {
		
				e.printStackTrace();
			}
			if(cusList==null){
				cusList=new ArrayList<Customer>();
			}
		}
 	
	
 
	
 			private void submit1(){
 			
 			
			String cid =up.getTbCid().getSelectedItem().toString();
 			String name=up.getTbCname().getText().trim();
 			String addr=up.getTbCaddress().getText().trim();
 			String email=up.getTbCemail().getText().trim();
 			String phn=up.getTbCphone().getText().trim();

 			/*if(cid.length()==0){
 				up.getLblMsg().setText("Enter Customer ID!!!");
 				up.getTbCid().requestFocus();
 			} */
 			if(name.length()==0){
 				up.getLblMsg().setText("Enter Customer Name!!!");
 				up.getTbCname().requestFocus();
 			} 
 			else if(addr.length()==0){
 				up.getLblMsg().setText("Enter Customer Address!!!");
 				up.getTbCaddress().requestFocus();
 			}
 			
 			else if(email.length()==0){
 				up.getLblMsg().setText("Enter Customer Email Address!!!");
 				up.getTbCemail().requestFocus();
 			}
 			
 			else if(phn.length()==0){
 				up.getLblMsg().setText("Enter Customer Phone number!!!");
 				up.getTbCphone().requestFocus();
 			}
 			
 			else{
		
			Customer cus=new Customer(cid, name,addr, email, phn);
			cusList.set(up.getUpdateIndex(), cus);
			try {
				CustFileIO.writeObj(cusList);
				JOptionPane.showMessageDialog(up, "Customer Record Updated!!!");
				up.getTbCname().setText("");
				
					
				} 
			catch (FileNotFoundException e1) {
					
					e1.printStackTrace();
				} 
			catch (IOException e1) {
					
					e1.printStackTrace();
				}
			}
 			
 				
 			up.getTbCphone().addKeyListener(this);
			
 	}
		
	
	public void control(){
		
		up.getBtnSave().addActionListener((event)->{
			
			submit1();
			
		});
		
		up.getBtnExit().addActionListener((event)->{
			up.dispose();
		});
		
		
		up.getBtnView().addActionListener((event)->{
			
			CustViewAll sv=new CustViewAll("View All Customer Data",null);
			
		});
		
	}




	@Override
	public void keyTyped(KeyEvent e) {
		char key=e.getKeyChar();
		if(!(Character.isDigit(key))){
			if(!(key==KeyEvent.VK_PERIOD)){
				e.consume();
			}
		}
		
	}




	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
