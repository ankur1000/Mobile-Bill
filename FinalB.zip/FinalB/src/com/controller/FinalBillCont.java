	package com.controller;

	import java.io.IOException;
import java.util.ArrayList;

	import javax.swing.JTable;

import pack.BillFileIO;
import pack.CustFileIO;

import com.model.Bill;
import com.model.Customer;
import com.view.CustViewAll;
import com.view.FinalBill;

	public class FinalBillCont {
		private String heading[]={"BILL ID","BILL DATE","CUST ID"," NAME","ADDRESS",
				"PHONE","STD","LOCAL SAME","LOCAL OTHER","LLINE","SMS SENT","ISD","BILL TOTAL"};
		private String rowData[][];
		private ArrayList<Bill> fbillList;
		private JTable table=null;
		public FinalBillCont() {
			//this.fbillList=f;
			try {
				fbillList=BillFileIO.readObj();
				
			} catch (IOException e) {
				
				fbillList=new ArrayList<Bill>();
				
				e.printStackTrace();
			}
			
		}
		public JTable viewAllBill(){  //view full table
			
			
				rowData =new String[fbillList.size()][13];
			
				Bill bill=null;
				for(int i=0;i<fbillList.size();i++){
					bill=fbillList.get(i);
//BILL ID","BILL DATE","CUSTOMER ID"," CUSTOMER NAME","CUSTOMER ADDRESS","CUSTOMER PHONE","MONTHLY USAGE","SMS SENT","TARIFF","TOTAL AMOUNT					
					rowData[i][0]=bill.getBillid();
					rowData[i][1]=bill.getBilldt();
					rowData[i][2]=bill.getCustomer().getId();
					rowData[i][3]=bill.getCustomer().getName();
					rowData[i][4]=bill.getCustomer().getAddress();
					rowData[i][5]=bill.getCustomer().getPhn_no();
					rowData[i][6]=bill.getStd();
					rowData[i][7]=bill.getLsame();
					rowData[i][8]=bill.getLother();
					rowData[i][9]=bill.getLl();
				    rowData[i][10]=bill.getSms();
				    rowData[i][11]=bill.getIsd();
				    rowData[i][12]=bill.getAmount();
				    
				     
				}
				table=new JTable(rowData,heading);
				return table;
		} 
		
		
		public JTable viewSingleBill(String bid){ //Finding details using Customer Id
		
				
				rowData =new String[1][10];
			
				Bill bill=null;
				for(int i=0;i<fbillList.size();i++){
					bill=fbillList.get(i);
					if(bill.getBillid().equals(bid)){
						rowData[0][0]=bill.getBillid();
						rowData[0][1]=bill.getBilldt().trim();
						rowData[0][2]=bill.getCustomer().getId();
						rowData[0][3]=bill.getCustomer().getName();
						rowData[0][4]=bill.getCustomer().getAddress();
						rowData[0][5]=bill.getCustomer().getPhn_no();
						rowData[0][6]=bill.getStd();
						rowData[0][7]=bill.getLsame();
						rowData[0][8]=bill.getLother();
						rowData[0][9]=bill.getLl();
					    rowData[0][10]=bill.getSms();
					    rowData[0][11]=bill.getIsd();
					    rowData[0][12]=bill.getAmount();
					    break;
						
					}
				}
				table=new JTable(rowData,heading);
				
			
				return table;
		

	} 


}
