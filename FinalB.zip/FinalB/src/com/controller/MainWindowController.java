package com.controller;

import com.view.AddCustForm;
import com.view.CustViewAll;
import com.view.ExistForm;
import com.view.Main1window;
import com.view.Mainwindow;
import com.view.TariffWindow;



public class MainWindowController {
	private Mainwindow mw1;
	public MainWindowController(Mainwindow mw) {
		this.mw1=mw;
	}
	
	public void control(){
		mw1.getBtnNew().addActionListener((e)->{
			AddCustForm acf=new AddCustForm("CUSTOMER ENTRY!!!");
			new CustController(acf).control();
		});
		
		mw1.getBtnExist().addActionListener((e)->{
			
			 ExistForm cf=new ExistForm("EXISTING CUSTOMER MENU");
			 new ExistController(cf).control();
			
			
		});
		mw1.getBtnTariff().addActionListener((e)->{
			TariffWindow tw=new TariffWindow("TARIFF", null);
		});
		
		mw1.getBtnReport().addActionListener((e)->{
			CustViewAll cv=new CustViewAll("VIEW DATABASE", null);
		});
		mw1.getBtnExit1().addActionListener((e)->{
			
			System.exit(0);
			
			
		});
	}
}
