package com.controller;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import pack.CustFileIO;

import com.model.Customer;
import com.view.AddCustForm;
import com.view.CustViewAll;
import com.view.DeleteCustomer;
import com.view.UpdateForm;


public class DeleteController implements KeyListener{
	private DeleteCustomer del;
	private ArrayList<Customer> cusList;
	public DeleteController(DeleteCustomer del) {
		this.del=del;
		try {
				cusList=CustFileIO.readObj();
			} 
			catch (FileNotFoundException e) {
			
				e.printStackTrace();
			} 
			catch (IOException e) {
		
				e.printStackTrace();
			}
			if(cusList==null){
				cusList=new ArrayList<Customer>();
			}
		}
 	
	
 
	
 			private void submit1(){
 			
 			
			String cid =del.getTbCid().getSelectedItem().toString();
 			String name=del.getTbCname().getText().trim();
 			String addr=del.getTbCaddress().getText().trim();
 			String email=del.getTbCemail().getText().trim();
 			String phn=del.getTbCphone().getText().trim();

 			
		
			Customer cus=new Customer(cid, name,addr, email, phn);
			cusList.set(del.getUpdateIndex(), cus);
			try {
				CustFileIO.writeObj(cusList);
				JOptionPane.showMessageDialog(del, "Customer Record Removed!!!");
				del.getTbCname().setText("");
				
				
					
				} 
			catch (FileNotFoundException e1) {
					
					e1.printStackTrace();
				} 
			catch (IOException e1) {
					
					e1.printStackTrace();
				}
			}
 			
 				
 				
	
	public void control(){
		
		del.getBtnSave().addActionListener((event)->{
			
			submit1();
			
		});
		
		del.getBtnExit().addActionListener((event)->{
			del.dispose();
		});
		
		
		del.getBtnView().addActionListener((event)->{
			
			CustViewAll sv=new CustViewAll("View All Customer Data",null);
			
		});
		
	}




	@Override
	public void keyTyped(KeyEvent e) {
		char key=e.getKeyChar();
		if(!(Character.isDigit(key))){
			if(!(key==KeyEvent.VK_PERIOD)){
				e.consume();
			}
		}
		
	}




	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}




	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
