//Controller for AddCustForm

package com.controller;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import pack.CustFileIO;

import com.model.Customer;
import com.view.AddCustForm;
import com.view.CustViewAll;


public class CustController implements KeyListener{
	private AddCustForm cust;
	private ArrayList<Customer> cusList;
	public CustController(AddCustForm cus) {
		this.cust=cus;
		try {
			cusList=CustFileIO.readObj();
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
		
			e.printStackTrace();
		}
		if(cusList==null){
			cusList=new ArrayList<Customer>();
		}
		cust.getTbCid().setText(autoGenerateId());
		
		cust.getTbCphone().addKeyListener(this);
			
	}
 	private void clear(){
 	
		cust.getTbCname().setText("");
		cust.getTbCaddress().setText("");
		cust.getTbCemail().setText("");
		cust.getTbCphone().setText("");
		cust.getTbCid().requestFocus();
		cust.getTbCid().setText(autoGenerateId());
	}
	
 private String autoGenerateId(){
	 String cid="C1000";
	 if(cusList.size()>0){
		 Customer customer=cusList.get(cusList.size()-1);
		 String retId=customer.getId();
		 int id=Integer.parseInt(retId.substring(1))+1;
		 cid="C"+String.valueOf(id);
	 }
	 return cid;
 }
	
 		private void submit(){
		String cid =cust.getTbCid().getText().trim();
		String name=cust.getTbCname().getText().trim();
		String addr=cust.getTbCaddress().getText().trim();
		String email=cust.getTbCemail().getText().trim();
		String phn=cust.getTbCphone().getText().trim();

		if(cid.length()==0){
			cust.getLblMsg().setText("Enter Customer ID!!!");
			cust.getTbCid().requestFocus();
		}
		else if(name.length()==0){
			cust.getLblMsg().setText("Enter Customer Name!!!");
			cust.getTbCname().requestFocus();
		} 
		else if(addr.length()==0){
			cust.getLblMsg().setText("Enter Customer Address!!!");
			cust.getTbCaddress().requestFocus();
		}
		
		else if(email.length()==0){
			cust.getLblMsg().setText("Enter Customer Email Address!!!");
			cust.getTbCemail().requestFocus();
		}
		
		else if(phn.length()==0){
			cust.getLblMsg().setText("Enter Customer Phone number!!!");
			cust.getTbCphone().requestFocus();
		}
		
		else{
			String Cid=cid;
			String Cname=name;
			String Caddr=addr;
			String Cemail=email;
			String Cphn=phn;
			
			Customer cus=new Customer(Cid, Cname, Caddr, Cemail, Cphn);
				cusList.add(cus);
				try {
					CustFileIO.writeObj(cusList);
					cust.getLblMsg().setText("Customer Registered!!!");
					clear();
				} catch (FileNotFoundException e1) {
					
					e1.printStackTrace();
				} catch (IOException e1) {
					
					e1.printStackTrace();
				}
			}
		}
	
	public void control(){
		
		cust.getBtnSubmit().addActionListener((event)->{
			submit();
		});
		cust.getBtnReset().addActionListener((event)->{
			clear();
		});
		cust.getBtnExit().addActionListener((event)->{
			cust.dispose();
		});
		cust.getbtnView().addActionListener((event)->{
			CustViewAll sv=new CustViewAll("View All Customer Data",null);
			
		});
		
	}
	@Override
	public void keyTyped(KeyEvent e) {
		char key=e.getKeyChar();
		if(!(Character.isDigit(key))){
			if(!(key==KeyEvent.VK_PERIOD)){
				e.consume();
			}
		}
		
	}
	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}
}
