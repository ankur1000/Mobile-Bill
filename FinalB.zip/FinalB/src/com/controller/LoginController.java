package com.controller;





import com.view.AddCustForm;
import com.view.Login;
import com.view.Mainwindow;
import com.view.AddCustForm;

public class LoginController {
	private Login login;
	
	
	public LoginController(Login login) {
		this.login=login;
		
		
	}
	public void control(){
		
		login.getBtnCancel().addActionListener((event)->{
			login.dispose();
		});
		login.getBtnLogin().addActionListener((event)->{
			
			
			
				String uname=login.getTfUname().getText().trim();
				String passwd=new String(login.getTfPasswd().getPassword()).trim();
				
				
				if((uname==null)||(uname.length()==0))
				{
					login.setLblErrMsg("Enter Username!!!");
					login.getTfUname().requestFocus();
				}
				else if((passwd==null)||(passwd.length()==0))
				{
					login.setLblErrMsg("Enter Pasword!!!");
					login.getTfPasswd().requestFocus();
				}
				
				else{
					
					if((uname.equals("admin"))&&(passwd.equals("pass"))){
						Mainwindow mw=new Mainwindow("Main Menu!!!");
						new MainWindowController(mw).control();
						login.dispose();
					}
					else{
						login.setLblErrMsg
						("Either Username or Password incorrect");
						login.getTfUname().setText("");
						login.getTfPasswd().setText("");
						login.getTfUname().requestFocus();
					}
				}
						
			
		});
	}
	

}
