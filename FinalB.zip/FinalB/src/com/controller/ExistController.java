package com.controller;

import com.view.AddCustForm;
import com.view.BillNewView;

import com.view.CustViewAll;
import com.view.DeleteCustomer;
import com.view.ExistForm;
import com.view.Mainwindow;

import com.view.AddCustForm;
import com.view.UpdateForm;

public class ExistController {

	private ExistForm ef1;
	public ExistController(ExistForm ef) {
		this.ef1=ef;
	}
	//AddCustForm ob=new AddCustForm("Add customer form");
	public void control(){
		
		ef1.getView().addActionListener((e)->{
			CustViewAll cv=new CustViewAll("View All", null);
		});
		ef1.getBtnDelete().addActionListener((e)->{
			DeleteCustomer del=new DeleteCustomer("Delete Customer");
			new DeleteController(del).control();
		});
		
		ef1.getBtnUpdatedetail().addActionListener((e)->{
			
			 UpdateForm up=new UpdateForm("Update Customer");
			new UpdateFormController(up).control();
			
			
		});
		
		
		ef1.getBtnBill().addActionListener((e)->{
			BillNewView bg =new BillNewView("BillNewView");
			new BillNewController(bg).billControl();
		});
		ef1.getBtnExit().addActionListener((e)->{
			ef1.dispose();
		});
	}
	
	
}
