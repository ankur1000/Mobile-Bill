package com.controller;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JOptionPane;

import com.view.FinalBill;
import com.controller.*;
import com.view.BillNewView;

import pack.BillFileIO;

import com.model.Bill;
import com.model.Customer;
import com.view.BillNewView;


public class BillNewController implements KeyListener {
    
	private BillNewView frmbill;
	private ArrayList<Bill> billList;
	

	public BillNewController(BillNewView bill) {
		
		this.frmbill = bill;
		
		try {
			billList=BillFileIO.readObj();
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
		
		if(billList==null){
			billList=new ArrayList<Bill>();
		}
			frmbill.getTfBid().setText(autoGenerateId());	
			frmbill.getTfLL().addKeyListener(this);
			frmbill.getTfIsd().addKeyListener(this);
			frmbill.getTfStd().addKeyListener(this);
			frmbill.getTfLocalOther().addKeyListener(this);
			frmbill.getTfsms().addKeyListener(this);
			frmbill.getTfLocalsame().addKeyListener(this);
	}
	
	
	
	public void billControl() {
		frmbill.getBtnExit().addActionListener((event)->{
			frmbill.dispose();
		});
		
		
		
		
		
		frmbill.getBtnSave().addActionListener((event)->{
			
			
			save();
			
			});
				
		frmbill.getBtnCancel().addActionListener((event)->{
			reset();
		});
	
		frmbill.getBtntotal().addActionListener((event)->{
			String val=total();
			//String sval=String.valueOf(val);
			frmbill.getTfTotal().setText(val);
			frmbill.getBtnSave().setEnabled(true);
			frmbill.getBtntotal().setEnabled(false);
			
		});
		
		frmbill.getViewBill().addActionListener((event)->{
			FinalBill fv=new FinalBill("Final Bill",null);
		});
		
		
		}
	private String autoGenerateId(){
		 String bid="C1000";
		 if(billList.size()>0){
			 Bill bill=billList.get(billList.size()-1);
			 String retId=bill.getBillid();
			 int id=Integer.parseInt(retId.substring(1))+1;
			 bid="C"+String.valueOf(id);
		 }
		 return bid;
	 }
	private void reset() {
		
		frmbill.getTfStd().setText("");
		frmbill.getTfLocalsame().setText("");
		frmbill.getTfLocalOther().setText("");
		frmbill.getTfLL().setText("");
		frmbill.getTfsms().setText("");
		frmbill.getTfIsd().setText("");
		frmbill.getTfname().setText("");
		frmbill.getTfID().setText("");
		frmbill.getTfTotal().setText("");
		//frmbill.getTf_Billdt().setText("");
		frmbill.getTfBid().setText(autoGenerateId());	
		
	}
	
	private void save() {
		
		
		
		
String bid=frmbill.getCbCid().getSelectedItem().toString().trim();
String bdt=frmbill.getTf_Billdt().getText().toString().trim();
String cid=frmbill.getCustomer().getId().trim();
String nm=frmbill.getCustomer().getName().trim();
String addr=frmbill.getCustomer().getAddress().trim();
String pn=frmbill.getCustomer().getPhn_no().trim();
String std=frmbill.getTfStd().getText().trim();
String ls=frmbill.getTfLocalsame().getText().trim();
String lo=frmbill.getTfLocalOther().getText().trim();
String ll=frmbill.getTfLL().getText().trim();
String sms=frmbill.getTfsms().getText().trim();
String isd=frmbill.getTfIsd().getText().trim();
String amt=frmbill.getTfTotal().getText().trim();


Bill bill1=new Bill(bid,bdt,std,ls,lo,ll,sms,isd,amt,frmbill.getCustomer());


billList.add(bill1);
try{
BillFileIO.writeObj(billList);
JOptionPane.showMessageDialog(frmbill, "Bill Generated!!!");
FinalBill fb=new FinalBill("Final Bill",bid);
new FinalBillCont().viewSingleBill(bid);
}
catch(FileNotFoundException e1){
e1.printStackTrace();
}
catch(IOException e1){
e1.printStackTrace();
}


		String id=frmbill.getTfBid().getText().trim();
		
		frmbill.getBtntotal().setEnabled(true);
		
		
		
		
		
	}
	public String total() {
		double total=250.0;
		total=Double.parseDouble(frmbill.getTfStd().getText())+Double.parseDouble(frmbill.getTfLocalsame().getText())+Double.parseDouble(frmbill.getTfLocalOther().getText())+Double.parseDouble(frmbill.getTfLL().getText())+Double.parseDouble(frmbill.getTfsms().getText())+Double.parseDouble(frmbill.getTfIsd().getText());
		total=total+(0.1224*total);
		String stotal=String.valueOf(total);
		return stotal;
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		char key=e.getKeyChar();
		if(!(Character.isDigit(key))){
			if(!(key==KeyEvent.VK_PERIOD)){
				e.consume();
			}
		}
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}	
	
	



}

