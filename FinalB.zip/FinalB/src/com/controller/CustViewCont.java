package com.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JTable;

import pack.CustFileIO;


import com.model.Customer;
import com.view.CustViewAll;

public class CustViewCont {
	private String heading[]={"Cust_ID","Name","Address","Email","Phone"};
	private String rowData[][];
	private ArrayList<Customer> custList;
	private JTable table=null;
	public CustViewCont() {
		try {
			custList=CustFileIO.readObj();
			
		} catch (IOException e) {
			
			custList=new ArrayList<Customer>();
			
			e.printStackTrace();
		}
	}
	public JTable viewAll(){  //view full table
		
		
			rowData =new String[custList.size()][5];
		
			Customer cust=null;
			for(int i=0;i<custList.size();i++){
				cust=custList.get(i);
				
				rowData[i][0]=cust.getId();
				rowData[i][1]=cust.getName();
				rowData[i][2]=cust.getAddress();
				rowData[i][3]=cust.getE_mail_id();
				rowData[i][4]=cust.getPhn_no();
				
			}
			table=new JTable(rowData,heading);
			return table;
	}
	
	
	public JTable viewCust(String cid){ //Finding details using Customer Id
		
			
			rowData =new String[1][4];
		
			Customer cust=null;
			for(int i=0;i<custList.size();i++){
				cust=custList.get(i);
				if(cust.getId()==cid){
					
					rowData[i][0]=cust.getId();
					rowData[i][1]=cust.getName();
					rowData[i][2]=cust.getAddress();
					rowData[i][3]=cust.getE_mail_id();
					rowData[i][4]=cust.getPhn_no();
				}
			}
			table=new JTable(rowData,heading);
			
		
			return table;
	}

}
