package com.view;
import java.util.*;
public class RemoveStudent {
public static void main(String[] args) {
	
	//System.out.println(dt);
	Calendar calIssue=Calendar.getInstance();
	calIssue.set(2014, 6,25 );
	Calendar calret=Calendar.getInstance();
	int daydiff=calret.get(Calendar.DAY_OF_MONTH)-calIssue.get(Calendar.DAY_OF_MONTH);
	System.out.println(calret.get(Calendar.DAY_OF_MONTH));
	System.out.println(calIssue.get(Calendar.DAY_OF_MONTH));
	
	System.out.println(daydiff);
	
}
}
