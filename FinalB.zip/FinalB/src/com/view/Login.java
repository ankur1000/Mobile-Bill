package com.view;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.border.Border;

import com.controller.LoginController;

public class Login extends JFrame {

	
	private JLabel lblUname,lblPasswd,lblErrMsg;
	private JTextField tfUname;
	private JPasswordField tfPasswd;
	private JPanel panel1,panel2;
	private JButton btnLogin,btnCancel;
	public Login(String title) throws HeadlessException {
		super(title);
		setLocationRelativeTo(null);;
		lblUname=new JLabel("Enter Username:");
		lblPasswd=new JLabel("Enter Password:");
		lblErrMsg=new JLabel("");
		lblErrMsg.setForeground(Color.red);
		
		tfUname=new JTextField(20);
		tfPasswd=new JPasswordField(20);
		
		panel1=new JPanel();
		panel2=new JPanel();
		
		btnLogin=new JButton("LOGIN");
		btnCancel=new JButton("EXIT");
		//registering the listener
		
		
		//panel1.setBackground(Color.yellow);
		panel1.add(lblUname);
		panel1.add(tfUname);
		panel1.add(lblPasswd);
		panel1.add(tfPasswd);
		panel1.add(lblErrMsg);
		
		Border border=BorderFactory.createLineBorder(Color.red);
		
		panel1.setBorder(border);
		
		panel2.add(btnLogin);
		panel2.add(btnCancel);
		
		Container cont=getContentPane();
		cont.add(panel1,BorderLayout.CENTER);
		cont.add(panel2,BorderLayout.SOUTH);
		
		setResizable(false);
		setVisible(true);
		setSize(350, 150);
	}
	
	public JButton getBtnLogin() {
		return btnLogin;
	}
	public JButton getBtnCancel() {
		return btnCancel;
	}

	public JPasswordField getTfPasswd() {
		return tfPasswd;
	}

	public JTextField  getTfUname() {
		return tfUname;
	}

	public void setLblErrMsg(String errMsg) {
		this.lblErrMsg.setText(errMsg);
	}
	
}
