package com.view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.HeadlessException;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.*;

import com.controller.CustViewCont;
import com.model.Customer;

import pack.CustFileIO;

public class CustViewAll extends JFrame {

	
	private JLabel lblHeading;
	private JTable custTable;
	public CustViewAll(String title,String id) throws HeadlessException {
		super(title);
		lblHeading=new JLabel("CUSTOMER DATA");
		lblHeading.setFont(new Font("Arial Bold",Font.ITALIC,20));
		
		Container con=getContentPane();
		if(id==null){
		custTable=new CustViewCont().viewAll();
		}
		else {
			String cid=id;
			custTable=new CustViewCont().viewCust(id);
		}
		JScrollPane scrollpane=new JScrollPane(custTable);
		
		
		con.add(lblHeading,BorderLayout.NORTH);
		con.add(scrollpane);
		
		
		setVisible(true);
		setResizable(false);
		
		setSize(400, 400);
	}
	

}
