package com.view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.HeadlessException;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.*;

import pack.CustFileIO;

import com.model.Customer;



public class ExistForm extends JFrame {
	public JLabel lblCustomerid;
	//private JTextField tbCid;
	private JButton btnDelete,btnUpdatepersonaldetails,btnUpdateusage,btnGenerationbill,btnReset,btnExit,btnView;
	private JPanel panel1,panel2;
	
	private JComboBox cbCid;
	private Customer customer;
	private ArrayList<Customer> custList;
	
		
	
	public ExistForm(String title) throws HeadlessException 
	{
		super(title);
		
		
		try {
			custList=CustFileIO.readObj();
		} catch (IOException e) {
			custList=new ArrayList<Customer>();
			e.printStackTrace();
		}
		
		String custId[]=new String[custList.size()];
		int index=0;
		for(Customer cust:custList){
			custId[index++]=cust.getId();
		}
		
		cbCid=new JComboBox(custId);
		cbCid.addItemListener((e)->{
			String cid=cbCid.getSelectedItem().toString();
			
		
		});
		
		
		lblCustomerid=new JLabel("Enter Customer id");
		
	
		
		
		btnDelete=new JButton("Delete");
		btnUpdatepersonaldetails=new JButton("Update Personal"
				+ "Details");
		btnUpdateusage=new JButton("Update Usage");
		btnGenerationbill=new JButton("Generate Bill");
		btnReset=new JButton("Reset");
		
		btnExit=new JButton("Exit");
		btnView=new JButton("View");
		panel1=new JPanel();
		panel2=new JPanel();
		panel1.add(lblCustomerid);
		panel1.add(cbCid);
		
		
		
		
		panel2.add(btnView);
		panel2.add(btnDelete);
		panel2.add(btnUpdatepersonaldetails);
		panel2.add(btnUpdateusage);
		panel2.add(btnGenerationbill);
		panel2.add(btnReset);
		panel2.add(btnExit);
		
		//abc=tbCid.getText();
		
		
		Container cont=getContentPane();
		
		cont.add(panel1,BorderLayout.CENTER);
		cont.add(panel2,BorderLayout.SOUTH);
		
		setVisible(true);
		pack();
		
		setVisible(true);
		pack();
		//setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	
	}

	public JButton getView(){
		return btnView;
	}
	
	public JButton getBtnDelete(){
		return btnDelete;
	}
	
	public JButton getBtnUpdatedetail(){
		return btnUpdatepersonaldetails;
	}
	public JButton getBtnUpdateusage(){
		return btnUpdateusage;
	}
	public JButton getBtnBill(){
		return btnGenerationbill;
	}
	public JButton getBtnReset(){
		return btnReset;
	}
	public JButton getBtnExit(){
		return btnExit;
	}
	public JComboBox getTbCid(){
		return cbCid;
	}
}
	
	


