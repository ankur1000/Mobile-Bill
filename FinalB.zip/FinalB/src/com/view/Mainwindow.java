package com.view;

import java.awt.Font;
import java.awt.Frame;
import java.awt.GridLayout;

import javax.swing.*;

public class Mainwindow extends JFrame {
	
	
	private JFrame window;
	private JLabel lblWelcome;
	private JButton btnExist,btnNew,btnExit1,btnReport,btnTariff;
	

	public Mainwindow(String title) {
		
		window=new JFrame(title);
		window.setLayout(new GridLayout(6, 1)); 
		
		Font f=new Font("CM Sans",Font.BOLD,15);
		
		lblWelcome= new JLabel("MAIN WINDOW : MENU PANEL");
		lblWelcome.setFont(f);
		
		btnExist = new JButton("EXISTING USER");
		btnNew = new JButton("NEW");
		btnReport=new JButton("REPORT");
		btnTariff=new JButton("TARIFF");
		btnExit1=new JButton("EXIT");
		
		
		window.add(lblWelcome);
		window.add(btnExist);
		window.add(btnNew);
		window.add(btnReport);
		window.add(btnTariff);
		window.add(btnExit1);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		window.setResizable(false);
		window.setSize(300,300);
		window.setVisible(true); 	
		
	}
	
		public JButton getBtnExist(){
			return btnExist;
		}
		public JButton getBtnNew(){
			return btnNew;
		}
		public JButton getBtnReport(){
			return btnReport;
		}
		public JButton getBtnTariff(){
			return btnTariff;
		}
		public JButton getBtnExit1(){
			return btnExit1;
		}
	

		
}



