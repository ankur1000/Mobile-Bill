package com.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.*;

public class AddCustForm extends JFrame 
{
	
	private JLabel lblCustomerid,lblCustomername,lblCustomeraddress,lblCustomerphone,lblCustomerEmail,lblMsg;
	private JTextField tbCid,tbCname,tbCaddress,tbCphone,tbEmail;
	private JButton btnReset,btnSubmit,btnExit,btnView;
	private JPanel panel1,panel2;
	
	public AddCustForm(String title) throws HeadlessException {
		super(title);
		
		
		lblMsg=new JLabel();
		lblMsg.setForeground(Color.red);
		
		lblCustomerid=new JLabel("Enter Customer id");
		tbCid=new JTextField(20);
		tbCid.setEnabled(false);
		
		lblCustomername=new JLabel("Enter Customer name");
		tbCname=new JTextField(20);
		
		lblCustomeraddress=new JLabel("Enter Customer address");
		tbCaddress=new JTextField(20);
		
		lblCustomerphone=new JLabel("Enter Customer phone");
		tbCphone=new JTextField(20);
		
		lblCustomerEmail=new JLabel("Enter Customer Email");
		tbEmail=new JTextField(20);
		
		btnSubmit=new JButton("SUBMIT");
		btnExit=new JButton("EXIT");
		btnReset=new JButton("RESET");
		btnView=new JButton("VIEW");
		
		
		
		panel1=new JPanel();
		panel2=new JPanel();
		
		
		panel1=new JPanel(new GridLayout(6,1));
		
		panel1.add(lblCustomerid);
		panel1.add(tbCid);
		panel1.add(lblCustomername);
		panel1.add(tbCname);
		panel1.add(lblCustomerphone);
		panel1.add(tbCphone);
		panel1.add(lblCustomeraddress);
		panel1.add(tbCaddress);
		panel1.add(lblCustomerEmail);
		panel1.add(tbEmail);
		panel1.add(lblMsg);
		
		panel2.add(btnSubmit);
		panel2.add(btnReset);
		panel2.add(btnExit);
		panel2.add(btnView);
		
		
		Container cont=getContentPane();
				
		cont.add(panel1,BorderLayout.CENTER);
		cont.add(panel2,BorderLayout.SOUTH);
		
		setVisible(true);
		pack();
				
		
	}

	public JTextField getTbCid() {
		return tbCid;
	}

	public JTextField getTbCname() {
		return tbCname;
	}

	public JTextField getTbCaddress() {
		return tbCaddress;
	}

	public JTextField getTbCphone() {
		return tbCphone;
	}
	public JTextField getTbCemail(){
		return tbEmail;
	}
	
	public JLabel getLblMsg() {
		return lblMsg;
	}
	public JButton getBtnReset() {
		return btnReset;
	}

	public JButton getBtnSubmit() {
		return btnSubmit;
	}

	public JButton getBtnExit() {
		return btnExit;
	}
	
	public JButton getbtnView(){
		return btnView;
	}


	

}
