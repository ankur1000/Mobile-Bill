package com.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.view.Login;
import com.controller.LoginController;

public class Main1window  extends JFrame  {
	
	private JLabel lblWelcome;

	private JButton btnAdmin,btnExit;
	
	private JPanel panel1;

	public Main1window(String title) throws HeadlessException {
		super(title);
		
		setLocationRelativeTo(null);
		Font f=new Font("CM Sans",Font.BOLD,20);
		lblWelcome= new JLabel("WELCOME : ADMIN PANEL");
		lblWelcome.setFont(f);
	
	
	
		btnAdmin = new JButton("ADMIN");
		btnExit = new JButton("EXIT");
	
		btnAdmin.addActionListener((e)->{
		Login login=new Login("Login Window");
		new LoginController(login).control();
	});
		btnExit.addActionListener((e)->{
			dispose();
		});
	
	

	
	panel1=new JPanel(new GridLayout(2,1));
	
	
	
	
	panel1.setBackground(Color.orange);
	
	
	
		
	panel1.add(btnAdmin);
	panel1.add(btnExit);
	
	
	
	
	Container cont=getContentPane();
	
	cont.add(lblWelcome,BorderLayout.NORTH);


	cont.add(panel1);
	
	
	setVisible(true);
	setResizable(false);
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setSize(450,300);
	
	}

	

	
	
}
	

