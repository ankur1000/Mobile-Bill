package com.view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.model.*;

import javax.swing.*;

import pack.CustFileIO;

public class BillNewView extends JFrame{
	private JFrame bwin;

	private JLabel lblBillID,lblStd,lblLocalsame,lblLocalOther,lblLL,lblsms,lblIsd,lblname,lblCid,lblBilldt,lblTotal;
	private JTextField tfBid,tfStd,tfLocalsame,tfLocalOther,tfLL,tfsms,tfIsd,tfname,tf_Billdt,tfTotal;
	private JComboBox cbCid;
	
	private JButton  btnSave,btnReset,btnExit,btntotal,btnVwBill;
	private Customer customer;
	private ArrayList<Customer> custList;
	public BillNewView(String title) {
		super(title);
		
		
		try {
			custList=CustFileIO.readObj();
		} catch (IOException e) {
			custList=new ArrayList<Customer>();
			e.printStackTrace();
		}
		
		String custIds[]=new String[custList.size()];
		int index=0;
		for(Customer cust:custList){
			custIds[index++]=cust.getId();
		}
		
		cbCid=new JComboBox(custIds);
		cbCid.addItemListener((e)->{
			String cid=cbCid.getSelectedItem().toString();
			
			for(Customer c:custList){
				if(c.getId().equals(cid)){
					customer=c;
					tfname.setText(customer.getName());
				}
			}
		});
		
		lblBillID=new JLabel("BILL ID");
		lblStd=new JLabel("STD USAGE");
		lblLocalsame= new JLabel("LOCAL USAGE SAME NETWORK");
		lblLocalOther=new JLabel("LOCAL OTHER NETWORK");
		lblLL=new JLabel("LANDLINE");
		lblsms=new JLabel("SMS");
		lblIsd=new JLabel("ISD");
		lblname=new JLabel("NAME");
		lblCid=new JLabel("CUSTOMER ID");
		
		
		lblBilldt=new JLabel("BILL DATE");
		lblTotal=new JLabel("TOTAL");
		
		tf_Billdt=new JTextField(20);
		tf_Billdt.setEnabled(false);
		
		DateFormat df=DateFormat.getDateInstance();
		tf_Billdt.setText(df.format(new Date()));
		tfBid=new JTextField(20);
		tfBid.setEnabled(false);
		tfIsd=new JTextField(20);
		tfLL=new JTextField(20);
		tfLocalOther=new JTextField(20);
		tfLocalsame=new JTextField(20);
		tfname=new JTextField(20);
		tfname.setEnabled(false);
		tfsms=new JTextField(20);
		tfStd=new JTextField(20);
		tfTotal=new JTextField(20);
		tfTotal.setEnabled(false);
		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		
		btnReset=new JButton("Reset");
		btnExit=new JButton("Exit");
		btnSave=new JButton("Save");
		btnSave.setEnabled(false);
		btntotal=new JButton("Generate Total");
		btnVwBill=new JButton("View Bill");
		panel1=new JPanel(new GridLayout(11,1));
		
		panel1.add(lblBillID);
		panel1.add(tfBid);
		panel1.add(lblBilldt);
		panel1.add(tf_Billdt);
		panel1.add(lblCid);
		panel1.add(cbCid);
		panel1.add(lblname);
		panel1.add(tfname);
		
		panel1.add(lblLocalsame);
		panel1.add(tfLocalsame);
		panel1.add(lblLocalOther);
		panel1.add(tfLocalOther);
		panel1.add(lblStd);
		panel1.add(tfStd);
		panel1.add(lblIsd);
		panel1.add(tfIsd);
		panel1.add(lblLL);
		panel1.add(tfLL);
		panel1.add(lblsms);
		panel1.add(tfsms);
		panel1.add(lblTotal);
		panel1.add(tfTotal);
		panel2.add(btntotal);
		panel2.add(btnSave);
		panel2.add(btnExit);
		panel2.add(btnReset);
		panel2.add(btnVwBill); 
		
		Container cont=getContentPane();
		cont.add(panel1,BorderLayout.CENTER);
		cont.add(panel2,BorderLayout.SOUTH);
		
		
		setVisible(true);
		setSize(1000, 650);
	}
	
	
	public JTextField getTfID() {
		return tfBid;
	}

	public JTextField getTfStd() {
		return tfStd;
	}

	public JTextField getTfLocalsame() {
		return tfLocalsame;
	}

	public JTextField getTfLocalOther() {
		return tfLocalOther;
	}

	public JTextField getTfLL() {
		return tfLL;
	}

	public JTextField getTfsms() {
		return tfsms;
	}

	public JTextField getTfIsd() {
		return tfIsd;
	}

	public JTextField getTfname() {
		return tfname;
	}

	

	public JTextField getTfe_mail_id() {
		return tf_Billdt;
	}

	

	public JButton getBtnSave() {
		return btnSave;
	}

	public JButton getBtnClear() {
		return btnReset;
	}

	public JButton getBtnExit() {
		return btnExit;
	}


	public JTextField getTfBid() {
		return tfBid;
	}


	public JTextField getTf_Billdt() {
		return tf_Billdt;
	}


	public JTextField getTfTotal() {
		return tfTotal;
	}


	public JComboBox getCbCid() {
		return cbCid;
	}


	public JButton getBtnCancel() {
		return btnReset;
	}


	public JButton getBtntotal() {
		return btntotal;
	}


	public Customer getCustomer() {
		return customer;
	}
	public JButton getViewBill() {
		return btnVwBill;
	}
	
	
}
