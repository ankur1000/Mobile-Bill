
	package com.view;

	import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Font;
import java.awt.HeadlessException;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.*;
import com.controller.*;
import com.controller.FinalBillCont;
import com.model.Customer;

import pack.CustFileIO;

	public class FinalBill extends JFrame {

		
		private JLabel lblHeading;
		private JTable fbillTable;
		public FinalBill(String title,String bid) throws HeadlessException {
			super(title);			lblHeading=new JLabel("BILL DATA");
			lblHeading.setFont(new Font("Arial Bold",Font.ITALIC,20));
			
			Container con=getContentPane();
			if(bid==null){
			fbillTable=new FinalBillCont().viewAllBill();
			}
			else {
				
				fbillTable=new FinalBillCont().viewSingleBill(bid);
			} 
			JScrollPane scrollpane=new JScrollPane(fbillTable);
			
			
			con.add(lblHeading,BorderLayout.NORTH);
			con.add(scrollpane);
			
			
			setVisible(true);
			
			
			setSize(800, 500);
		}
		

	}



