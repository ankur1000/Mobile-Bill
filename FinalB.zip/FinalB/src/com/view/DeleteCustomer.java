package com.view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.model.*;

import javax.swing.*;

import pack.CustFileIO;

public class DeleteCustomer extends JFrame{
	

	private JLabel lblCid,lblCustomername,lblCustomeraddress,lblCustomerphone,lblCustomerEmail,lblMsg;
	private JTextField tbCname,tbCaddress,tbCphone,tbEmail,tbCid;
	private JComboBox cbCid;
	private JPanel panel1,panel2;
	private JButton  btnSave,btnExit,btnView;
	private int updateIndex;
	private ArrayList<Customer> custList;
	public DeleteCustomer(String title) {
		super(title);
		
		
		try {
			custList=CustFileIO.readObj();
		} catch (IOException e) {
			custList=new ArrayList<Customer>();
			e.printStackTrace();
		}
		
	
		
		String custIds[]=new String[custList.size()];
		int index=0;
		for(Customer cust:custList){
			custIds[index++]=cust.getId();
		}
		
		cbCid=new JComboBox(custIds);
		cbCid.addItemListener((e)->{
			String cid=cbCid.getSelectedItem().toString();
			updateIndex=0;
			for(Customer c:custList){
				if(c.getId().equals(cid)){
					tbCid.setText(null);
					tbCname.setText("");
					tbCaddress.setText("");
					tbCphone.setText("");
					tbEmail.setText("");
					break;
					
				}
				updateIndex++;
			}
		});
		
		
		lblCid=new JLabel("CUSTOMER ID");
		tbCid=new JTextField(20);
		lblMsg=new JLabel();
		lblCustomername=new JLabel("CUSTOMER NAME");
		tbCname=new JTextField(20);
		lblCustomeraddress=new JLabel("CUSTOMER ADDRESS");
		tbCaddress=new JTextField(20);
		lblCustomerphone=new JLabel("CUSTOMER PHONE");
		tbCphone=new JTextField(20);
		lblCustomerEmail=new JLabel("CUSTOMER EMAIL ID");
		tbEmail=new JTextField(20);
		
		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		
		
		btnExit=new JButton("Exit");
		btnSave=new JButton("Save");
		btnView=new JButton("View");
		
		
		panel1=new JPanel();
		panel2=new JPanel();
		
		
		panel1=new JPanel(new GridLayout(6,1));
		
		panel1.add(lblCid);
		panel1.add(cbCid);
		
		panel1.add(lblCustomername);
		panel1.add(tbCname);
		panel1.add(lblCustomerphone);
		panel1.add(tbCphone);
		panel1.add(lblCustomeraddress);
		panel1.add(tbCaddress);
		panel1.add(lblCustomerEmail);
		panel1.add(tbEmail);
		panel1.add(lblMsg);
		
		panel2.add(btnSave);
		panel2.add(btnExit);
		panel2.add(btnView);
		
	
	
	Container cont=getContentPane();
	
	cont.add(panel1,BorderLayout.CENTER);
	cont.add(panel2,BorderLayout.SOUTH);
	
	setVisible(true);
	pack();
			
	
}

	
public int getUpdateIndex() {
		return updateIndex;
	}


public JComboBox getTbCid() {
	return cbCid;
}
public JTextField getTbTCid(){
	return tbCid;
}

public JTextField getTbCname() {
	return tbCname;
}

public JTextField getTbCaddress() {
	return tbCaddress;
}

public JTextField getTbCphone() {
	return tbCphone;
}
public JTextField getTbCemail(){
	return tbEmail;
}




public JButton getBtnSave() {
	return btnSave;
}

public JButton getBtnExit() {
	return btnExit;
}

public JButton getBtnView(){
	return btnView;
}
public JLabel getLblMsg() {
	return lblMsg;
}


}
	
	
	
