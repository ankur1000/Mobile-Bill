package com.view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.HeadlessException;
import java.awt.Label;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.border.Border;


public class TariffWindow extends JFrame
{
	private JLabel lblHeading;
	private JLabel lblLocal,lblCharge,lblSecond,lblStd,lblIsd,rental;
	private JLabel lblSame,lblOther,lblLand,lblSMS;
	private JLabel tfLCT2T,tfLCT2O,tfLCT2L,tfLST2T,tfLST2O,tfLST2L,tfLSMSC;
	//private JButton btnOk,btnUpdate,btnExit;
	private JPanel panel1,panel2,panel3;
	
	
	//JComboBox first=new JComboBox();
	
	public TariffWindow(String title, TariffWindow objTariffWindowect) throws HeadlessException 
	{
		super(title);
		
	
		lblHeading=new JLabel("                                         --------TARIFF PLANS---------                                 ");
		
		lblLocal=new JLabel("LOCAL");
		lblStd=new JLabel("STD");
		lblIsd=new JLabel("ISD");
		rental=new JLabel("RENTAL: Rs.250");
		lblCharge=new JLabel("       Call rates",lblCharge.CENTER);
		lblSecond=new JLabel("    Seconds",lblSecond.RIGHT);
		
		lblSame=new JLabel(" Same Network"); 
		lblOther=new JLabel(" Other Network");
		lblLand=new JLabel("Landline");
		lblSMS=new JLabel("SMS");
		
		
		tfLCT2T=new JLabel("Rs.1");
		tfLCT2O=new JLabel("Rs.1");
		tfLCT2L=new JLabel("Rs.1");
		tfLST2T=new JLabel("60");
		tfLST2O=new JLabel("60");
		tfLST2L=new JLabel("60");
		tfLSMSC=new JLabel("Rs.1");
		
		
		// btnOk=new JButton("OK");
		// btnUpdate=new JButton("UPDATE");
		 //btnExit=new JButton("EXIT");
		 
		
		
		
		
		panel1=new JPanel();
		panel2=new JPanel();
		panel3=new JPanel();
		
		
		panel2=new JPanel(new GridLayout(4,1));
		
		
	/*	first.addItem("LOCAL");
		first.addItem("STD");
		first.addItem("ISD");
		first.setName("select area");
		first.setSize(100 ,50);
		*/
		
		
		panel1.add(lblHeading);
	//	panel1.add(first);
		
		
		panel1.add(lblCharge);
		panel1.add(lblSecond);
		
		
		
		
		panel2.add(lblLocal);//label Local T to T
		panel2.add(tfLCT2T);//text field local charges T 2 T
		panel2.add(tfLST2T);//text fields local seconds T 2 T
		
		panel2.add(lblOther);//label Local T to Others
		panel2.add(tfLCT2O);//text field local charges T 2 Others
		panel2.add(tfLST2O);//text fields local seconds T 2 Others
		
		panel2.add(lblLand);//label Local T to landline
		panel2.add(tfLCT2L);//text field local charges T 2 landline
		panel2.add(tfLST2L);//text fields local seconds T 2 landline
		
		panel2.add(lblSMS);//label Local sms.
		panel2.add(tfLSMSC);//textfield for local sms charge.
		panel3.add(rental);
/*		panel3.add(btnOk,BorderLayout.LINE_END);
		panel3.add(btnUpdate,BorderLayout.LINE_END);
		panel3.add(btnExit,BorderLayout.LINE_END);
	
	*/	
		
		
		
		
	
		
		GridLayout gr=new GridLayout(3, 0, 0, 0);
		setLayout(gr);
		add(panel1);
		add(panel2);
		add(panel3);
		panel1.setBorder(null);
		panel1.setBackground(Color.ORANGE);
		
		panel2.setBorder(null);
		panel2.setBackground(Color.WHITE);
		panel3.setBackground(Color.GREEN);
		
		
		setVisible(true);
		setSize(438,500);
		//setResizable(false);
		setLocationRelativeTo(null);
		//setResizable(false);
		
		
		
	}


}





