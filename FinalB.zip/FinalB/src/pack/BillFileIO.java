
	
	
	package pack;


	import java.io.*;
import java.util.ArrayList;

import com.model.Bill;
import com.model.Customer;

	public class BillFileIO {

		public static void writeObj(ArrayList<Bill> bil) throws FileNotFoundException, IOException{
			
			ObjectOutputStream objip=new ObjectOutputStream
					(new FileOutputStream("BillOb.dat"));
			objip.writeObject(bil);
			System.out.println("Data Saved");
			objip.close();
			
		}
		public static ArrayList<Bill> readObj() throws FileNotFoundException, IOException{
			ObjectInputStream obinp=new ObjectInputStream
					(new FileInputStream("BillOb.dat"));
			ArrayList<Bill> arrObj=new ArrayList<Bill>();
			
			try {
				
					arrObj=(ArrayList<Bill>)obinp.readObject();
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return arrObj;
		} 
		
		
		
		
	}



