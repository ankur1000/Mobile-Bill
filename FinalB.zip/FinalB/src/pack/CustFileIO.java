package pack;


import java.io.*;
import java.util.ArrayList;

import com.model.Customer;

public class CustFileIO {

	public static void writeObj(ArrayList<Customer> cus) throws FileNotFoundException, IOException{
		
		ObjectOutputStream objip=new ObjectOutputStream
				(new FileOutputStream("CustomerOb.dat"));
		objip.writeObject(cus);
		System.out.println("Data Saved");
		objip.close();
		
	}
	public static ArrayList<Customer> readObj() throws FileNotFoundException, IOException{
		ObjectInputStream obinp=new ObjectInputStream
				(new FileInputStream("CustomerOb.dat"));
		ArrayList<Customer> arrObj=new ArrayList<Customer>();
		
		try {
			
				arrObj=(ArrayList<Customer>)obinp.readObject();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return arrObj;
	} 
	
	
	
	
}
