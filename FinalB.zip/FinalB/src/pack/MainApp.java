package pack;


import com.controller.BillNewController;
import com.view.BillNewView;
import com.view.Main1window;



public class MainApp {
public static void main(String[] args) {
	
	new Main1window("ADMIN PANEL");

	}
}
